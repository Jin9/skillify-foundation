package middleware

import (
	"context"
	"time"

	"github.com/gin-gonic/gin"
)

// Timeout applies a timeout to request context.
func Timeout(timeout time.Duration) gin.HandlerFunc {
	return func(c *gin.Context) {
		ctx, cancel := context.WithTimeout(c.Request.Context(), timeout)
		defer cancel()
		c.Request = c.Request.WithContext(ctx)
		c.Next()
	}
}
